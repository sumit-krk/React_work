import './App.css';
import AppLayout from './Component/AppLayout';

function App() {
  return (
    <div>
      <AppLayout />
    </div>
  );
}

export default App;
